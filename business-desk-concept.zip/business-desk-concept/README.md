# Business Name Here — 3D landing concept

Scroll-driven office scene built with **Vite + React Three Fiber**. A blurred
office backdrop sits behind a photoreal desk; scrolling slides the chair aside
and dollies the camera into the monitor until the screen fills ~70% of the
frame. The screen is a small interactive "OS" — three app icons, each of which
projects a semi-transparent glass panel beside the monitor that the camera
smoothly tracks.

## Run it

```bash
npm install
npm run dev
```

Then open the URL Vite prints (usually http://localhost:5173).

> First load fetches a city HDRI from the drei asset CDN for reflections, so
> the very first run needs internet. Everything else is local.

## How it flows

1. **Hero** — "Business Name Here", sub-text, and a *Let's get started* button
   (the button smooth-scrolls you straight in).
2. **Scroll** — `App.jsx` turns page scroll into a 0→1 value; the chair
   (`ikea_markus.001`) slides + turns out of the way and the camera interpolates
   from the wide "hero" pose to the "monitor" pose.
3. **Docked** — the on-screen UI becomes interactive. Click an icon → that
   section's glass panel appears to the left and the camera glides to frame it.
   Close (× or `Esc`) returns to the monitor.

## Where to change things

| You want to…                         | File |
|--------------------------------------|------|
| Retune framing, chair, panel, easing | `src/config.js` |
| Edit section names / copy / icons    | `src/sections.js` |
| Restyle hero, screen, panels, colors | `src/index.css` |
| Change the backdrop image            | `public/img/office-bg.png` |
| Swap the model                       | `public/models/full_desk_opt.glb` |

### Aligning the on-screen UI
The HTML overlay is mapped onto the monitor using the measured screen rectangle.
If it doesn't sit perfectly on the glass, set `CONFIG.DEBUG = true` in
`src/config.js` — you'll see the screen rect (cyan) and panel rects (pink) as
wireframes. Nudge `screen.widthFactor / heightFactor / yLift / forward` (and
`screen.scale`) until the cyan rect hugs the screen, then turn DEBUG off.

If the tech panel appears on the wrong side, flip `CONFIG.panel.side` (−1 / +1).
If the chair slides the wrong way, flip the signs in `CONFIG.chair.slide`.

## The model
`full_desk_opt.glb` is your `full_desk.glb` optimized 29.4 MB → 4.5 MB (Draco
geometry + WebP textures, resized to ≤2048px). The animated parts — `monitor_27`
and `ikea_markus.001` — were preserved as separate named nodes.

## Notes / trade-offs
- One panel is open at a time; all three share the same slot to the monitor's
  side, so switching apps feels like the panel re-forming. To stack them, offset
  each `rig.panels[i]` in `DeskModel.jsx`.
- Textures are WebP (not KTX2). WebP gets nearly the same download size with zero
  runtime setup; KTX2 needs a basis transcoder + `renderer.detectSupport` wiring.
  Say the word and I'll switch to KTX2 for lower GPU memory.
- Mobile works but the framing is tuned for landscape.
